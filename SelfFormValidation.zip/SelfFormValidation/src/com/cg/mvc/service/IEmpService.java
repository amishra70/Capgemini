package com.cg.mvc.service;

import java.util.List;

import com.cg.mvc.bean.Employee;

public interface IEmpService {
	public void addEmployee(Employee e);
	public List<Employee> fetchAllEmployee();
	public boolean checkForLogin(String uName,String pwd);
	public Employee check(int id);
	public Employee updateEmployee(Employee emp, Employee ee);
	public void deleteEmployee(int id);
	public boolean checkLogin(Employee emp);
}
