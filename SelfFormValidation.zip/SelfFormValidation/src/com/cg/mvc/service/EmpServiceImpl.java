package com.cg.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mvc.bean.Employee;
import com.cg.mvc.dao.IEmpDao;

@Service
@Transactional
public class EmpServiceImpl implements IEmpService{
	@Autowired
	IEmpDao eDao;
	@Override
	public void addEmployee(Employee e) {
		eDao.addEmployee(e);
	}

	@Override
	public List<Employee> fetchAllEmployee() {
		return eDao.fetchAllEmployee();
	}

	@Override
	public boolean checkForLogin(String uName, String pwd) {
		return eDao.checkForLogin(uName, pwd);
	}

	@Override
	public Employee check(int id) {
		return eDao.check(id);
	}

	@Override
	public Employee updateEmployee(Employee emp, Employee ee) {
		return eDao.updateEmployee(emp,ee);
	}

	@Override
	public void deleteEmployee(int id) {
		
		eDao.deleteEmployee(id);
	}

	@Override
	public boolean checkLogin(Employee emp) {
		// TODO Auto-generated method stub
		return eDao.checkLogin( emp);
	}

}
