package com.cg.mvc.exception;

public class EmployeeException extends Exception{
	public EmployeeException(String msg) {
		super(msg);
	}
}
