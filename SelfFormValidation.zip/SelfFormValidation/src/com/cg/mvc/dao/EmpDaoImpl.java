package com.cg.mvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.mvc.bean.Employee;
@Repository
public class EmpDaoImpl implements IEmpDao{

	@PersistenceContext
	private EntityManager em; 
	
	@Override
	public void addEmployee(Employee e) {
		em.persist(e);
	}

	@Override
	public List<Employee> fetchAllEmployee() {
		TypedQuery<Employee> qq = em.createQuery("from Employee", Employee.class);
		List<Employee> list = qq.getResultList();
		return list;
	}

	@Override
	public boolean checkForLogin(String uName, String pwd) {
		
		return false;
	}

	@Override
	public Employee check(int id) {
		TypedQuery<Employee> qq = em.createQuery("from Employee", Employee.class);
		List<Employee> list = qq.getResultList();
		for(Employee ee:list) {
			if(id == ee.getId()) {
				return ee;
			}
		}
		return null;
	}

	@Override
	public Employee updateEmployee(Employee empl, Employee ee) {
		Employee emp = em.find(Employee.class, empl.getId());
		emp.setCity(ee.getCity());
		emp.setDesignation(ee.getDesignation());
		emp.setName(ee.getName());
		emp.setUserName(ee.getUserName());
		emp.setSalary(ee.getSalary());
		//emp.setPassword(ee.getPassword());
		//em.merge(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(int id) {
		
		em.remove(em.find(Employee.class, id));;
	}

	@Override
	public boolean checkLogin(Employee emp) {
		TypedQuery<Employee> qq = em.createQuery("from Employee", Employee.class);
		List<Employee> list = qq.getResultList();
		for(Employee ee:list) {
			if(ee.getUserName().equals(emp.getUserName())&&(ee.getPassword().equals(emp.getPassword()))) {
				return true;
			}
		
		}
		return false;
	}

}
