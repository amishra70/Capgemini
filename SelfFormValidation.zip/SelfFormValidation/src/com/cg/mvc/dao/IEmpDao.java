package com.cg.mvc.dao;

import java.util.List;

import com.cg.mvc.bean.Employee;

public interface IEmpDao {
	public void addEmployee(Employee e);
	public List<Employee> fetchAllEmployee();
	public boolean checkForLogin(String uName,String pwd);
	//public List<Employee> fetchAllEmployee();
	public Employee check(int id);
	public Employee updateEmployee(Employee emp, Employee ee);
	public void deleteEmployee(int id);
	public boolean checkLogin(Employee emp);
}
