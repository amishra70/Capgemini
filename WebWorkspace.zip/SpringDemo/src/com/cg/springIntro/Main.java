package com.cg.springIntro;





import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@SuppressWarnings("deprecation")
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource res =new ClassPathResource("config.xml");
		XmlBeanFactory factory = new XmlBeanFactory(res);
		Test t = (Test) factory.getBean("mybean");
		t.hello();
	}

}
