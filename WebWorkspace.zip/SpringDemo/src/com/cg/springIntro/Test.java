package com.cg.springIntro;

public class Test {

public void hello(){
	System.out.println("Hello");
		}
}
