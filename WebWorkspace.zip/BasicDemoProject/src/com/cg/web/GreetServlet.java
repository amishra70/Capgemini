package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "GreetServletName", urlPatterns = { "/GreetServletMap" })
public class GreetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public GreetServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		System.out.println("Init of GreetServlet is callled.");
	}

	public void destroy() {
		System.out.println("destroy of GreetServlet is callled.");
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		out.println("<font color='red'><b>Happy Diwali</b></font>");
		out.println("<a href='html/Login.html'> Login</a>");
	}

}
