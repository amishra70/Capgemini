package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl {
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	public LoginDaoImpl() {
	}

	public Login getUserDetails(String unm) {
		con = DBUtil.getCon();
		System.out.println("In Dao Got Connection " + con);
		String sql = "select * from LOGIN_TBL where user_name=?";
		Login usr=null;
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, unm);
			rs = pst.executeQuery();
			rs.next();
			usr = new Login(rs.getString("user_name"),
					rs.getString("user_pass"));
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return usr;
	}
}
