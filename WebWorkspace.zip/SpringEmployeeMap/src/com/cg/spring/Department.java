package com.cg.spring;

import java.util.List;

public class Department {
	private String deptName;
	private List<Employee> emps;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public List<Employee> getEmps() {
		return emps;
	}

	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}

	public void display() {
		for (Employee e : emps) {
			System.out.println("id is:"+e.getId());
			System.out.println("name is:"+e.getName());
			System.out.println("department is:"+e.getDept());
		}

	}

	@Override
	public String toString() {
		return deptName;
	}

}
