package com.cg.empl;

public class Employee {
private int id;
private String name;
private Department dept;/*
public Employee(int id, String name, Department dept) {
	super();
	this.id = id;
	this.name = name;
	this.dept = dept;
}*/
public int getId() {
	return id;
}
public String getName() {
	return name;
}
public Department getDept() {
	return dept;
}
public void setId(int id) {
	this.id = id;
}
public void setName(String name) {
	this.name = name;
}
public void setDept(Department dept) {
	this.dept = dept;
}
public String getDeptName(){
	return dept.getDeptName();
}
}
