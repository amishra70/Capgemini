package com.cg.empl;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

@SuppressWarnings("deprecation")
public class MainMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XmlBeanFactory xb = new XmlBeanFactory(new ClassPathResource("config.xml"));
		Employee e =(Employee) xb.getBean("emp");
		System.out.println(e.getId());
		System.out.println(e.getName());
		System.out.println(e.getDeptName());
	}

}
