package com.cg.mble;

public class Mobile {
private String compName;
private String mobType;
private int price;
public String getCompName() {
	return compName;
}/*
public void setCompName(String compName) {
	this.compName = compName;
}*/
public String getMobType() {
	return mobType;
}/*
public void setMobType(String mobType) {
	this.mobType = mobType;
}*/
public int getPrice() {
	return price;
}/*
public void setPrice(int price) {
	this.price = price;
}*/
public Mobile(String compName, String mobType, int price) {
	super();
	this.compName = compName;
	this.mobType = mobType;
	this.price = price;
}

}
