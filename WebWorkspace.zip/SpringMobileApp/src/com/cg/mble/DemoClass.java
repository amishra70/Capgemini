package com.cg.mble;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;



@SuppressWarnings("deprecation")
public class DemoClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource(
				"config.xml"));
		Mobile t = (Mobile) factory.getBean("mybean");
		System.out.println(t.getCompName());
		System.out.println(t.getMobType());
		System.out.println(t.getPrice());
	}
}
