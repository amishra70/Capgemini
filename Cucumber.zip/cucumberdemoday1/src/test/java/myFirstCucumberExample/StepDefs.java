package myFirstCucumberExample;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {

	@Given("^I have a wallet$")
	public void i_have_a_wallet() throws Throwable {
		System.out.println("This is given");
	}

	@When("^That means I have some Money$")
	public void that_means_I_have_some_Money() throws Throwable {
		System.out.println("This is when");
	}

	@Then("^I can lend you money$")
	public void i_can_lend_you_money() throws Throwable {
		System.out.println("This is then");
	}

}
