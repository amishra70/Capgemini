package ScenarioOutLineEg;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class TestDefs {
	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.out.println("This id Given");
	}

	@Given("^User has the valid username and password$")
	public void user_has_the_valid_username_and_password() throws Throwable {
		System.out.println("This id Given");
	}

	@When("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {
		System.out.println("This id When");
	}

	@Then("^Application takes to the 'Hotel Booking' page$")
	public void application_takes_to_the_Hotel_Booking_page() throws Throwable {
		System.out.println("This id Then");
	}
}
