package pleaseTest;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestDefs {
	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.out.println("This id Given");
	}

	@When("^User enters the valid username and valid password$")
	public void user_enters_the_valid_username_and_valid_password(DataTable arg1) throws Throwable {
		System.out.println("This id When");
	}

	@When("^Clicks on Log in$")
	public void clicks_on_Log_in() throws Throwable {
		System.out.println("This id When");
	}

	@Then("^Application takes to the 'Index' Page$")
	public void application_takes_to_the_Index_Page() throws Throwable {
		System.out.println("This id Then");
	}
	@When("^User enters deails$")
	public void user_enters_deails() throws Throwable {
		System.out.println("This id When"); 
	}

	@Then("^Application takes to 'Log in' Page$")
	public void application_takes_to_Log_in_Page() throws Throwable {
		System.out.println("This id Then");
	}

}