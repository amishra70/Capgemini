package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoClass {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	String url = "jdbc:mysql://localhost/reni";
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url,"root","root");
		System.out.println("Enter Employee Id");
		int id = sc.nextInt();
		System.out.println("Enter Name:");
		String empName = sc.next();
		System.out.println("Enter Gendre");
		String gen = sc.next();
		System.out.println("Enter Employee Age");
		int age= sc.nextInt();
		System.out.println("Enter Employee Salary");
		double sal = sc.nextDouble();
		PreparedStatement stat = con.prepareStatement("insert into employee values(?,?,?,?,?)");
		stat.setInt(1, id);
		stat.setString(2, empName);
		stat.setString(3, gen);
		stat.setInt(4, age);
		stat.setDouble(5,sal);
		int  rs= stat.executeUpdate();
		/*while(rs.next()){
		System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getInt("age")+"\t"+rs.getDouble(5));
		}*/
		System.out.println(rs+"LL");
		con.close();
		sc.close();
		} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
}
}
