package com.cg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class MainAp4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		System.out.println("Enter Employee Id");
		int id = sc.nextInt();

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url, "system", "root");
			CallableStatement stat = con.prepareCall("{?=call getEmpSalary(?)}");
			stat.setInt(2, id);
			stat.registerOutParameter(1, Types.NUMERIC);
			stat.execute();
			double sal = stat.getDouble(1);
			System.out.println("Salary of the employee with Id "+id+" = "+sal);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		sc.close();
	}
}
