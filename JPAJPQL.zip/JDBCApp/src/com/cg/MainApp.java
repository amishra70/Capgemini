package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainApp {
	public static void main(String[] args) {
		//String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String url = "jdbc:mysql://localhost/reni";
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			
			/*Class.forName("com.mysql.jdbc.Driver");*/
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			
			// Stablishing Connection
			
			
			Connection con = DriverManager.getConnection(url, "root", "root");
			
			// JDBC Statement
			
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from employee;");
			while (rs.next()) {
				System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t"
						+ rs.getString(3) + "\t" + rs.getInt("age") + "\t"
						+ rs.getDouble(5));
			}
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}
	} 
}
