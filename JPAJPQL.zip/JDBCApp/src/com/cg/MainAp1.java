package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class MainAp1 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	String url = "jdbc:mysql://localhost/reni" ;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(url,"root","root");
		System.out.println("Enter Employee Id");
		int id = sc.nextInt();
		System.out.println("Enter Employee Salary");
		double sal = sc.nextDouble();
		PreparedStatement stat = con.prepareStatement("update employee set salary=?where eno=?");
		stat.setDouble(1,sal);
		stat.setInt(2, id);
		int result = stat.executeUpdate();
		System.out.println(result+"L");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	sc.close();
	}}

