package com.cg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class MainAP3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		System.out.println("Enter Employee Id");
		int id = sc.nextInt();

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url, "system", "root");
			CallableStatement stat = con.prepareCall("{call getEmployeeById(?,?)}");
			stat.setInt(1, id);
			stat.registerOutParameter(2, Types.VARCHAR);
			stat.execute();
			String name=stat.getString(2);
			System.out.println("Name of the employee with Id "+id+" = "+name);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		sc.close();
	}
}
