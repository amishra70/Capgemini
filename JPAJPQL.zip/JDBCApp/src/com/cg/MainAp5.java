package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Scanner;

public class MainAp5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		System.out.println("Enter Employee Id");
		int id1 = sc.nextInt();
		System.out.println("Enter Employee Id");
		int id2 = sc.nextInt();
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, "system", "root");
			con.setAutoCommit(false);
			PreparedStatement stat1 = con.prepareStatement("update employee set salary = salary+10000 where eno = 1001");			
			PreparedStatement stat2 = con.prepareStatement("update employee set salary = salary-10000 where eno = 1002");
			PreparedStatement stat3 = con.prepareStatement("delete employee where eno = 1003");
			PreparedStatement stat4 = con.prepareStatement("delete employee where eno = 1004");
			stat1.executeUpdate();
			stat2.executeUpdate();
			Savepoint sp1 = con.setSavepoint();
			stat3.executeUpdate();
			Savepoint sp2 = con.setSavepoint();
			stat4.executeUpdate();
			con.rollback(sp2);
			con.commit();
			System.out.println("Updated");
			System.out.println("yup");
		} catch (ClassNotFoundException e1) {
			try {
				con.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			e1.printStackTrace();
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		sc.close();
	}
}
