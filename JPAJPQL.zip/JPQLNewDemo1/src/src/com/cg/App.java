package src.com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		
	Vehicle v= new Vehicle();
	v.setVehicleName("Car");
	TwoWheeler tw = new TwoWheeler();
	tw.setVehicleName("Bike");
	tw.setSteeringHandle("Bike Steering Handle");
	FourWheeler fw = new FourWheeler();
	fw.setVehicleName("Porsche");
	fw.setSteeringWheel("Porsche Steeringwheel");
	
	
	
	
		em.getTransaction().begin();
		em.persist(v);
		em.persist(tw);
		em.persist(fw);
		em.getTransaction().commit();
		
		em.clear();
		fac.close();
		}
}
