package com.cg.emp.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;

public class Client {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int choice = 0;

		while (true) {
			System.out.println(" 1.Display Employees " + "\n 2.Add an Employee "
					+ "\n 3.Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				displayEmployee();
				break;
			case 2:
				addEmployee();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice.");
				break;

			}
		}

	}

	private static void addEmployee() {
		Employee emp = new Employee();
		System.out.println("Enter Employe Id:");
		emp.setId(sc.nextInt());
		System.out.println("Enter Employe Name:");
		emp.setName(sc.next());
		System.out.println("Enter Gender:");
		emp.setGender(sc.next());
		System.out.println("Enter Age:");
		emp.setAge(sc.nextInt());
		System.out.println("Enter Salary:");
		emp.setSalary(sc.nextInt());
		EmployeeService service = new EmployeeServiceImpl();
		try {
			int result = service.addEmployee(emp);
			if (result != 1) {
				System.err.println("No Row inserted.");
			} else {
				System.out.println("Employee details saved!!");
			}
		} catch (EmployeeException e) {
			System.err.println("Error:" + e.getMessage());
		}

	}

	private static void displayEmployee() {
		EmployeeService service = new EmployeeServiceImpl();
		try {
			List<Employee> employees = service.getAllEmployee();
			for (Employee employee : employees) {
				System.out.println(employee);
			}
		} catch (EmployeeException e) {
			System.err.println("Error" + e.getMessage());
		}

	}

}
