package com.cg.emp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.emp.exception.EmployeeException;

public class DbUtil {
/*	public static Connection getConnection() throws EmployeeException{
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			return DriverManager.getConnection(url,"system","root");
		} catch (ClassNotFoundException e) {
			throw new EmployeeException(e.getMessage());
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		
		
		
	}*/
	public static EntityManager getEntityManager(){
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		return fac.createEntityManager();
		
	}
}
