package com.cg;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity

public class UserDetail {




	@Id @GeneratedValue
	private int userId;
	private String userName;
	
	/*@OneToOne(cascade=CascadeType.ALL)//if it is not cascade then both will be persisted differently
	@JoinColumn(name = "Vid")
	private Vehicle vechile;
	
	public Vehicle getVechile() {
		return vechile;
	}
	public void setVechile(Vehicle vechile) {
		this.vechile = vechile;
	}*/
	
	
	//@OneToMany(cascade=CascadeType.ALL,mappedBy="user")//--it will create a diff.table
	@ManyToMany(cascade=CascadeType.ALL,mappedBy="userList")//--it won't create a diff. table only a extra column in vehicle
	//@JoinTable(name="UV",joinColumns=@JoinColumn(name="userId"),inverseJoinColumns=@JoinColumn(name="vid"))
	private List<Vehicle> vehicle=new ArrayList<Vehicle>();
	
	public List<Vehicle> getVehicle() {
		return vehicle;
	}
	public void setVehicle(List<Vehicle> vehicle) {
		this.vehicle = vehicle;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "UserDetails [userId=" + userId + ", userName=" + userName
				+ /*", vechile=" + vechile +*/ "]";
	}
	
	
	
}
