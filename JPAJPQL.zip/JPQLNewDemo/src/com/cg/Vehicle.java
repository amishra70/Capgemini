package com.cg;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Vehicle {
	@Id
	@GeneratedValue
	private int vahicleId;
	private String vehicleName;
/*
	@OneToOne(mappedBy = "vechile")
	private UserDetail user;*/

	/*public UserDetail getUser() {
		return user;
	}

	public void setUser(UserDetail user) {
		this.user = user;
	}*/

	//@ManyToMany(mappedBy="vechile")
	@ManyToMany
	private List<UserDetail> userList = new ArrayList<UserDetail>();
	

	public List<UserDetail> getUserList() {
		return userList;
	}

	public void setUserList(List<UserDetail> userList) {
		this.userList = userList;
	}
/*@ManyToOne
	private UserDetail user;

	public UserDetail getUser() {
		return user;
	}

	public void setUser(UserDetail user) {
		this.user = user;
	}*/
	public int getVahicleId() {
		return vahicleId;
	}

	public void setVahicleId(int vahicleId) {
		this.vahicleId = vahicleId;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	@Override
	public String toString() {
		return "Vehicle [vahicleId=" + vahicleId + ", vehicleName="
				+ vehicleName + "]";
	}

}
