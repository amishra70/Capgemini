package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {
	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		
		/*UserDetail user = new UserDetail();
		user.setUserName("Anil");
		
		Vehicle v = new Vehicle();
		v.setVehicleName("Car");
		
		user.setVechile(v);
		v.setUser(user);
		
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();*/
		
	/*	UserDetail user = new UserDetail();
		user.setUserName("Anil");
		
		Vehicle v = new Vehicle();
		v.setVehicleName("Car");
		Vehicle v1 = new Vehicle();
		v1.setVehicleName("Jeep");
		user.getVehicle().add(v);
		user.getVehicle().add(v1);
		//v1.setUser(user);
		//v.setUser(user);
		
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		*/
		
		UserDetail user = new UserDetail();
		user.setUserName("Anil");
		
		Vehicle v = new Vehicle();
		v.setVehicleName("Car");
		Vehicle v1 = new Vehicle();
		v1.setVehicleName("Jeep");
		user.getVehicle().add(v);
		user.getVehicle().add(v1);
		v.getUserList().add(user);
		v.getUserList().add(user);
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		
		em.clear();
		fac.close();
		}
}
