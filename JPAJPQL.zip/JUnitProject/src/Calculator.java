
public class Calculator {

		public int sqrt(int num){
			return (int)Math.sqrt(num);
		}
		public static int divide(int num){
			return(100/num);
		}
		

}
