package com.cg;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries({
@NamedQuery(name="getAllEmployees", query="from Employee"),
@NamedQuery(name="getAllEmployeeByGender", query="select emp from Employee emp where emp.gender=:gen")})
public class Employee {
	@Id
	private int eno;
	private String name;
	private String gender;
	private int age;
	private double salary;
	public int getEno() {
		return eno;
	}
	public Employee(int eno, String name, String gender, int age, double salary) {
		super();
		this.eno = eno;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.salary = salary;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", name=" + name + ", gender=" + gender
				+ ", age=" + age + ", salary=" + salary + "]";
	}
	
	
}
