package com.cg;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class App {
	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		Scanner sc =new Scanner(System.in);
		// Fetching all the table
		/*String strQuery = "from Employee";
		//String strQuery = "select emp from Employee emp";--It will give the same output as above
		TypedQuery<Employee> q = em.createQuery(strQuery, Employee.class);
		List<Employee> emp = q.getResultList();
		for (Employee emp2 : emp) {
			System.out.println(emp2);
		}/*
		 //Fetching Name Only
		  String strQuery = "select name from Employee";
		
		TypedQuery<String> q = em.createQuery(strQuery, String.class);
		List<String> emp = q.getResultList();
		for (String emp2 : emp) {
			System.out.println(emp2);
		}*/
		
		//Fetching only Male from gender 
		/*
		System.out.print("Enter Gender: ");
		String gender = sc.next();
		TypedQuery<Employee> q = em.createQuery("from Employee where gender=?",Employee.class);
		 * q.setParameter(1, gender);
		TypedQuery<Employee> q = em.createQuery("from Employee where gender=:gen",Employee.class);
		q.setParameter("gen", gender);
		List<Employee> emp = q.getResultList();
		for (Employee emp2 : emp) {
			System.out.println(emp2);
		}
		*/
		
		/*
		System.out.print("Enter Employee Id: ");
		int id = sc.nextInt();
		TypedQuery<Employee> q = em.createQuery("from Employee where gender=?",Employee.class);
		 * q.setParameter(1, gender);
		TypedQuery<Employee> q = em.createQuery("from Employee where eno=:empId",Employee.class);
		q.setParameter("empId", id);
		Employee emp = q.getSingleResult();
		
			System.out.println(emp);
		
		*/
		
		
		/*em.getTransaction().begin();
		
		System.out.print("Enter Employee Id: ");
		int id = sc.nextInt();
		System.out.print("Enter Gender: ");
		String gender = sc.next();
		Query q = em.createQuery("update Employee set gender=:gen where eno=:id");
		q.setParameter("gen", gender);
		q.setParameter("id", id);
		q.executeUpdate();
		em.getTransaction().commit();
		*/
		
		
		// Fetching one row using find with the help of primary key
		 /* Employee u=em.find(Employee.class, 1001);
		System.out.println(u);*/
		
		/*em.getTransaction().begin();
		 Employee u=em.find(Employee.class, 1001);
			System.out.println(u);
			u.setName("Amana");
			em.getTransaction().commit();*/
		
		
		
		
	
		/*TypedQuery<EmpData> emps = em.createQuery("select name,salary from Employee",EmpData.class);*/
		/*System.out.print("Enter Employee Id: ");
		int id = sc.nextInt();
		String str = "delete from Employee where eno=:id";
		Query q=em.createQuery(str);
		q.setParameter("id", id);
		em.getTransaction().begin();
		q.executeUpdate();
		em.getTransaction().commit();*/
		
	/*	TypedQuery<Employee> q = em.createNamedQuery("getAllEmployees",Employee.class);
		List<Employee> emp = q.getResultList();
		for (Employee emp2 : emp) {
			System.out.println(emp2);
		}
		
		
		System.out.print("Enter Gender: ");
		String gender = sc.next();
		TypedQuery<Employee> qq = em.createNamedQuery("getAllEmployeeByGender",Employee.class);
		qq.setParameter("gen", gender);
		List<Employee> empp = qq.getResultList();
		
		for (Employee emp2 : empp) {
			System.out.println(emp2);
		}*/
	/*	em.getTransaction().begin();
		em.persist(new Employee(1099,"Kavita","Female",28,100));
		em.getTransaction().commit();*/
		TypedQuery<Double> qq= em.createQuery("select MAX(e.salary) as salary from Employee e GROUP BY e.name HAVING e.name in ?", Double.class);
		qq.setParameter(1, "Kavita");
		double aa=qq.getSingleResult();
		System.out.println(aa);
		sc.close();
		em.close();
		fac.close();

	}
}
