package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Useretails")
public class User {
	@Id //Id will become primary key
	@Column(name="User_Id")
	private int userId;
	@Column(name="User_name",nullable=false,unique=false)
	private String userName;
	private int age;
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", age="
				+ age + "]";
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
