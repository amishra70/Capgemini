package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {

	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = fac.createEntityManager();
		/*UserDetails user = new UserDetails();
		user.setUserId(103);
		user.setUserName("Shilpa");
		user.setAge(20);*/
		User u = new User();
		u.setUserId(109);
		u.setUserName("Shilpa");
		u.setAge(20);
		em.getTransaction().begin();
		/*UserDetails u=em.find(UserDetails.class,100);
		UserDetails u1=em.find(UserDetails.class,102);
		System.out.println(u);
		System.out.println(u1);
		em.detach(u);*/
		
		/*em.persist(user);
		user.setUserName("Shipra name");*/
		em.persist(u);
		em.getTransaction().commit();
		System.out.println("User Stored");
		em.clear();
		fac.close();

	}

}
